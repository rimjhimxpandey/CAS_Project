package becognizant;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;


public class BeCognizantHome {
	
	WebDriver driver;
	
	//Constructor...
	
	public BeCognizantHome(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	//WebElements...
	
	@FindBy(xpath = "//button[contains(@title,'Account manager')]") WebElement user;	
	@FindBy(xpath = "//div[contains(@id, 'currentAccount_primary')]") WebElement primaryDetails;
	@FindBy(xpath = "//div[contains(@id, 'currentAccount_secondary')]") WebElement secondaryDetails;
	
	@FindBy(xpath = "//button[@name = 'People']") WebElement people;
	@FindBy(xpath = "//a[@name = 'Rewards, Life and Work']") WebElement rewardsLW;
	@FindBy(xpath = "//a[@name = 'Holiday Schedules']") WebElement holiday;

	
	//Launching the URL...
	
	public void webPageSetup(String url) {
		
		System.out.println("webPageSetup method called...");
		
		try {
			
			driver.get(url);
			System.out.println("Web Page has been set up");
			Thread.sleep(35000);
			
		} catch(Exception e) {
			System.out.println("Web page failed to load");
			Assert.fail();
			
		}

	}
	
	
	//Capturing User Details -->
	
	public boolean captureInfo() throws Exception {
		
		System.out.println("captureInfo method called...");
		
		// Implicit Wait...
		driver.manage().timeouts().implicitlyWait(Duration.ofMinutes(1));
		
		// Step 1 : Clicking on the user...
		user.click();
		
		//Wait...
		Thread.sleep(2000);
		
		// Step 2 : Getting details of the user...
		String userDetailsP = primaryDetails.getText();
		String userDetailsS = secondaryDetails.getText();
		
		//Printing the User Details...
		System.out.println("User Details: \nName: " + userDetailsP + "\nMail: " + userDetailsS);
		
		//Checking if the user details is Empty or not...
		if (userDetailsP.isEmpty() || userDetailsS.isEmpty()) return true;
		else return false;
		
	}
	
	
	//People --> Rewards, life and work --> Holiday Schedules...
	
	public void toHolidaySchedules() throws Exception {
		
		System.out.println("toholidaySchedules method called...");
		
		Actions action = new Actions(driver);
		
		//Clicking on People Header...
		people.click();
		
		//Wait...
		Thread.sleep(2000);
		
		//Hovering on Rewards, Life and Work...
		action.moveToElement(rewardsLW).perform();
		
		//Wait...
		Thread.sleep(2000);
		
		//Clicking on Holiday Schedules...
		holiday.click();
		
		//Wait...
		Thread.sleep(3000);
		
	}
	
	
}
