package becognizant;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BeCognizantHolidaySchedules {
	

	WebDriver driver;	
	
	
	//Constructor...
	
	public BeCognizantHolidaySchedules(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	//WebElements...
	
	@FindBy(xpath = "//div[text()='Holiday Schedules']") WebElement text;
	@FindBy(xpath = "//h4") WebElement sectionElements1;
	@FindBy(xpath = "//h4/following-sibling::a") WebElement sectionElements2;
	@FindBy(xpath = "//h4/parent::div/following-sibling::p") List<WebElement> sectionElements3;
	@FindBy(xpath = "//h2//strong") WebElement year;
	@FindBy(xpath = "//span[contains(text(),'India')]") WebElement indiaAUKI;
	

	//Fetching the text...
	
	public String getTextHolidaySchedules() {
		
		System.out.println("getTextHolidaySchedules method called...");
		
		//Returning the Text...
		return text.getText();
		
	}
	
	
	//Fetching the tooltip...
	
		public String getToolTipHolidaySchedules() {
			
			System.out.println("getToolTipHolidaySchedules method called...");
			
			//Returning the Text...
			return text.getAttribute("title");
			
		}
	

	//Details present in Holiday Schedules Section...
	
	public boolean sectionDetails() {
		
		System.out.println("sectionDetails method called...");
		
		String details = "";
		
		details = "Heading: " + sectionElements1.getText() + "\n";
		details += "Link: " + sectionElements2.getAttribute("href") + "\n" + "Paragraph: ";
		
//		ArrayList<WebElement> sectionList = new ArrayList<>	(sectionElements3);
		
		for (WebElement ele : sectionElements3) {
			
			details += ele.getText() + "\n";
			
		}
		
		//Printing the details
		System.out.println(details);
		
		if (details.length() <= 26) return true;
		else return false;
		
	}
	
	
	//Fetching the year from the Holiday Calendar...
	
	public String getHolidayCalendarYear() throws Exception {
		
		System.out.println("getHolidayCalendarYear method called...");
		
		//Wait...
		Thread.sleep(3000);
		
		return year.getText();
		
	}
	
	
	//Clicking --> India, Americas & UKI calendars...
	
	public void toIndiaAUKI() throws Exception {
		
		System.out.println("toIndiaAUKI method called...");
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		js.executeScript("arguments[0].scrollIntoView(true);", year);
		
		//Wait...
		Thread.sleep(5000);
		
		//Clicking on the India based location button
		indiaAUKI.click();
		
		//Wait...
		Thread.sleep(5000);
		
	}
	
	
}
