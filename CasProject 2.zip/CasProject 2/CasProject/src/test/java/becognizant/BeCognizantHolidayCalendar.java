package becognizant;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class BeCognizantHolidayCalendar {
	
	WebDriver driver;
	
	
	//Constructor...
	
	public BeCognizantHolidayCalendar(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	//WebElements...
	
	@FindBy(xpath = "//span[text()='Type']/preceding-sibling::i") WebElement type;
	@FindBy(xpath = "//button[@name='Filter by']") WebElement filterBy;
	@FindBy(xpath = "//span[text()='pdf']") WebElement pdf;
	@FindBy(xpath = "//button[@data-automationid='FilterPanel-Apply']") WebElement apply;
	
	@FindBy(xpath = "//div[@class='ms-List-page']/child::div//img") List<WebElement> items;
	@FindBy(xpath = "//div[contains(@class, 'headerWrapper')]//i[@data-icon-name='StatusCircleCheckmark']") WebElement selectAll;
	@FindBy(xpath = "//button[@name='Download']") WebElement downloadAll;
	
	@FindBy(xpath = "//button[contains(text(),'India')]") WebElement indiaCalendar;
	@FindBy(xpath = "//span[contains(text(),'India')]") WebElement calendarName;
	@FindBy(xpath = "//button[contains(@title,'India')]") WebElement tooltip;
	
	@FindBy(xpath = "//button[@data-automationid='overflowButton']") WebElement threeDots;
	@FindBy(xpath = "//button[@name='Version history']") WebElement versionHistory;
	@FindBy(xpath = "//p[text()='Version history']") WebElement versionHistoryName;
	
	@FindBy(xpath = "//iframe[@title='Version history']") WebElement frame;	
	@FindBy(xpath = "//div[@id='DeltaPlaceHolderMain']/table/tbody/tr/td[@class]") List<WebElement> tableData;
	
	
	//Selecting PDF from filter --> Type --> Filter By --> PDF...
	
	public void selectPDF() throws Exception {
		
		//Clicking on the type file...
		type.click();
		
		//Wait...
		Thread.sleep(2000);		
		
		//Clicking on the filter button...
		filterBy.click();
		
		//Wait...
		Thread.sleep(2000);
		
		//Selecting PDF from the types...
		pdf.click();
		
		//Wait...
		Thread.sleep(2000);
		
		//Clicking on apply...
		apply.click();
		
		//Wait...
		Thread.sleep(3000);
	}
	
	
	//Verification-->
	
	public boolean fetchAllElementType() {
		
		System.out.println("fetchAllElementType method called...");
		
		ArrayList<String> types = new ArrayList<>();
		
		for (WebElement ele : items) {
			
			types.add(ele.getAttribute("alt"));
			
		}
		
		boolean isTypePDF = true;
		
		for (String str : types) {
			
			if (!str.equals("pdf")) isTypePDF = false;
		}
		
		return isTypePDF;
		
	}
	
	
	//Download all calendar files...
	
	public void downloadAllFiles() throws Exception {
		
		System.out.println("downloadAllFiles method called...");
		//Selected all the files...
		selectAll.click();
		
		//Wait...
		Thread.sleep(2000);
		
		//Downloading all the files...
		downloadAll.click();
		System.out.println("All files downloaded");
		
		Thread.sleep(3000);
		
	}
	
	
	//Clicking India Calendar...
	
	public void indiaCalendar() {
		
		System.out.println("indiaCalendar method called...");
		
		indiaCalendar.click();
			
	}
	
	
	//Fetching Calendar name...
	
	public String calendarName() {
		
		System.out.println("calendarName method called...");
		
		String name = calendarName.getText();
		
		return name;
		
	}
	
	
	//Fetching tool tip...

	
	public String tooltipText() throws Exception {
			
		System.out.println("toolTipText method called...");
			
		String name = tooltip.getAttribute("title");
			
		//Wait...
		Thread.sleep(5000);
			
		return name;
			
	}
	
	
	//Clicking --> Three dots --> Version History...
	
	public String toVersionHistory() throws Exception {
		
		System.out.println("toVersionHistory method called...");
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		//Clicking on Three dots...
		js.executeScript("arguments[0].click();", threeDots);
		
		//Wait...
		Thread.sleep(3000);
		
		//Clicking on Version History...
		js.executeScript("arguments[0].click();", versionHistory);
		
		//Wait...
		Thread.sleep(10000);
		
		return versionHistoryName.getText();
		
	}
	
	
	//Printing Version History Details...
	
	public void verionHistoryDetails() {
		
		System.out.println("verionHistoryDetails method called...");
		
		//Switching to iframe...
		driver.switchTo().frame(frame);
		
		ArrayList<String> list = new ArrayList<>();
		
		//Printing the details...
		for (WebElement ele : tableData) {
			
			String details = ele.getText();
			
			list.add(details);

		}
		
		System.out.println("Version History Details: ");
		
		int i = 0;
		System.out.println("No." + " Modified " + " Modified By " + " Size " + " Comments "); 
		for (String str : list) {
			System.out.print(str + " ");
			i++;
			
			if (i == 5) {
				i = 0;
				System.out.print("\n");
			}
		}
		
		
	}
	

}
